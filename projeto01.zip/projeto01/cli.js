import pegaArquivo from "./index.js";
import chalk from "chalk";
import validaURL from "./http-validacao.js";

 const caminho  = process.argv

//console.log(pegaArquivo(caminho[2]))

 async function processatexto(caminhoDoArquivo){
     const resultado = await pegaArquivo(caminhoDoArquivo[2])
        
     if(caminho[3] === 'validar'){
         console.log(chalk.bgGreen('Lista validados: '), await validaURL(resultado))
     }else{
        console.log (chalk.bgYellow('Lista de Links: '), resultado)
     }
 }

 processatexto(caminho)