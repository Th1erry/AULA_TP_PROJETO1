import chalk from 'chalk';
import fs from 'fs';





function extrairLink(texto){
    const regex = /\[([^\]]*)\]\((https?:\/\/[^$#\s].[^\s]*)\)/gm
    const arrayResultados = []


let temp;
while ((temp = regex.exec(texto))!= null){
    arrayResultados.push({[temp[1]] : [temp[2]]})

 } return arrayResultados === 0 ? "Não há links" : arrayResultados;
}


function trataErro(erro){
    throw new Error (chalk.red(erro.code, "Não há arquivo no caminho."));
}

async function pegaArquivo(caminhoDoArquivo){
    /*callback*/
    /*const endcoding = 'utf-8';
    fs.readFile(caminhoDoArquivo, endcoding, (_, texto) => {
        if(erro){
            trataErro(erro);

        }
        console.log(chalk.green(texto));
    })*/


    /*promisse*/
   /*fs.promises
       .readFile(caminhoDoArquivo, 'utf-8')
       .then((texto)=> console.log(chalk.bgBlue(texto)))
       .catch((erro)=> trataErro(erro))*/
    try{
    const texto = await fs.promises.readFile(caminhoDoArquivo, 'utf-8')
    return(extrairLink(texto))
    }catch(erro){
        trataErro(erro)
    }
    

   
}

//extrairLink(texto);
//pegaArquivo('./arquivos/texto.md');

export default pegaArquivo

